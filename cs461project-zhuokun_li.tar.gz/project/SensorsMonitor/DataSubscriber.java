/**
 * Created by Kent Lee on 10/19/2016.
 */
public interface DataSubscriber {
    void handleData(MoteViewMsg msg);
}
